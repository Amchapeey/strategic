from kyt import *
import subprocess
import time
import datetime as DT
import random
import requests
import pwd  # added to check for existing usernames
from telethon import events, Button  # ensure these are imported as needed

def generate_unique_trial_username():
    """Return a unique trial username not already in /etc/passwd."""
    while True:
        candidate = "trialX" + str(random.randint(1000, 9999))
        try:
            pwd.getpwnam(candidate)
            # User exists, try a new one.
        except KeyError:
            return candidate

# DELETESSH
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    
    async def delete_ssh_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond("**Username To Be Deleted:**")
            user_event = user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user_input = (await user_event).raw_text
            cmd = f'printf "%s\n" "{user_input}" | delssh'
        try:
            output = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception:
            await event.respond(f"**User** `{user_input}` **Not Found**")
        else:
            await event.respond(f"**Successfully Deleted** `{user_input}`")
    
    if a == "true":
        await delete_ssh_(event)
    else:
        await event.answer("🛡 Unauthorized Access", alert=True)

# CREATE SSH
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    
    async def create_ssh_(event):
        # Get username
        async with bot.conversation(chat) as user_conv:
            await event.respond("**Username:**")
            user_event = user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user_input = (await user_event).raw_text
        # Get password
        async with bot.conversation(chat) as pw_conv:
            await event.respond("**Password:**")
            pw_event = pw_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw_input = (await pw_event).raw_text
        # Get expiry (in days)
        async with bot.conversation(chat) as exp_conv:
            await event.respond("**Choose Expiry Day**", buttons=[
                [Button.inline(" 3 Day ", "3"), Button.inline(" 7 Day ", "7")],
                [Button.inline(" 30 Day ", "30"), Button.inline(" 60 Day ", "60")]
            ])
            exp_event = exp_conv.wait_event(events.CallbackQuery)
            exp_input = (await exp_event).data.decode("ascii")
        
        # Simulated processing messages
        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(3)
        await event.edit("`Processing Crate Premium Account`")
        time.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(2)
        await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(3)
        await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(2)
        await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Processing... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Wait.. Setting up an Account`")
        
        cmd = (f'useradd -e `date -d "{exp_input} days" +"%Y-%m-%d"` '
               f'-s /bin/false -M {user_input} && echo "{pw_input}\\n{pw_input}" | passwd {user_input}')
        try:
            subprocess.check_output(cmd, shell=True)
        except Exception:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp_input))
            msg = f"""
**━━━━━━━━━━━━━━━━━**
**⚡ SSH OVPN ACCOUNT ⚡**
**━━━━━━━━━━━━━━━━━**
**» Username         :** `{user_input.strip()}`
**» Password         :** `{pw_input.strip()}`
**━━━━━━━━━━━━━━━━━**
**» Host             :** `{DOMAIN}`
**» Host Slowdns     :** `{HOST}`
**» Pub Key          :** `{PUB}`
**» Port OpenSSH     :** `443, 80, 22`
**» Port DNS         :** `443, 53 ,22`
**» Port Dropbear    :** `443, 109`
**» Port Dropbear WS :** `443, 109`
**» Port SSH WS      :** `80, 8080, 8081-9999`
**» Port SSH SSL WS  :** `443`
**» Port SSL/TLS     :** `222-1000`
**» Port OVPN WS SSL :** `443`
**» Port OVPN SSL    :** `443`
**» Port OVPN TCP    :** `443, 1194`
**» Port OVPN UDP    :** `2200`
**» Proxy Squid      :** `3128`
**» BadVPN UDP       :** `7100, 7300, 7300`
**━━━━━━━━━━━━━━━━━**
**» Save Link Account:** `https://{DOMAIN}:81/ssh-{user_input.strip()}.txt`
**» Expired Until:** `{later}`
**» 🤖@chapeey**
"""
            await event.respond(msg)
    
    if a == "true":
        await create_ssh_(event)
    else:
        await event.answer("🛡 Unauthorized Access", alert=True)

# SHOW SSH
@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    
    async def show_ssh_(event):
        cmd = 'bot-member-ssh'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
        
{z}

**Show All SSH User**
**» 🤖@chapeey**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
    
    if a == "true":
        await show_ssh_(event)
    else:
        await event.answer("🛡 Unauthorized Access", alert=True)

# TRIAL SSH (Fixed for Minutes)
@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    
    async def trial_ssh_(event):
        async with bot.conversation(chat) as exp_conv:
            await event.respond("**Choose Expiry Minutes**", buttons=[
                [Button.inline(" 10 minutes ", "10"), Button.inline(" 15 minutes ", "15")],
                [Button.inline(" 30 minutes ", "30"), Button.inline(" 60 minutes ", "60")]
            ])
            exp_event = exp_conv.wait_event(events.CallbackQuery)
            exp_input = (await exp_event).data.decode("ascii")
        
        # Generate a unique trial username
        user = generate_unique_trial_username()
        pw = "1"
        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(3)
        await event.edit("`Processing Crate Premium Account`")
        time.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(2)
        await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(3)
        await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(2)
        await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Processing... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Wait.. Setting up an Account`")
        
        # Build the command string:
        # 1. Create the trial user with an expiration date set to now + exp_input minutes.
        # 2. Set the password by piping echo -e (with newline) into passwd.
        # 3. Start a new tmux session running the trial command.
        cmd = (
            f'useradd -e `date -d "+{exp_input} minutes" +"%Y-%m-%d %H:%M:%S"` '
            f'-s /bin/false -M {user} && '
            f'echo -e "{pw}\\n{pw}" | passwd {user} && '
            f'tmux new-session -d -s {user} "trial trialssh {user} {exp_input}"'
        )
        try:
            subprocess.check_output(cmd, shell=True)
        except Exception:
            await event.respond("**User Already Exist**")
        else:
            # Display the expiry in minutes as chosen
            msg = f"""
**━━━━━━━━━━━━━━━━━**
**⚡ SSH OVPN ACCOUNT ⚡**
**━━━━━━━━━━━━━━━━━**
**» Username         :** `{user.strip()}`
**» Password         :** `{pw.strip()}`
**━━━━━━━━━━━━━━━━━**
**» Host             :** `{DOMAIN}`
**» Host Slowdns     :** `{HOST}`
**» Pub Key          :** `{PUB}`
**» Port OpenSSH     :** `443, 80, 22`
**» Port DNS         :** `443, 53 ,22`
**» Port Dropbear    :** `443, 109`
**» Port Dropbear WS :** `443, 109`
**» Port SSH WS      :** `80, 8080, 8081-9999`
**» Port SSH SSL WS  :** `443`
**» Port SSL/TLS     :** `222-1000`
**» Port OVPN WS SSL :** `443`
**» Port OVPN SSL    :** `443`
**» Port OVPN TCP    :** `443, 1194`
**» Port OVPN UDP    :** `2200`
**» Proxy Squid      :** `3128`
**» BadVPN UDP       :** `7100, 7300, 7300`
**━━━━━━━━━━━━━━━━━**
**» Payload WSS      :** `GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━━**
**» OpenVPN WS SSL   :** `https://{DOMAIN}:81/ws-ssl.ovpn`
**» OpenVPN SSL      :** `https://{DOMAIN}:81/ssl.ovpn`
**» OpenVPN TCP      :** `https://{DOMAIN}:81/tcp.ovpn`
**» OpenVPN UDP      :** `https://{DOMAIN}:81/udp.ovpn`
**━━━━━━━━━━━━━━━━━**
**» Save Link Account:** `https://{DOMAIN}:81/ssh-{user.strip()}.txt`
**» Expired Until:** `{exp_input} Minutes`
**» 🤖@chapeey**
"""
            await event.respond(msg)
    
    if a == "true":
        await trial_ssh_(event)
    else:
        await event.answer("🛡 Unauthorized Access", alert=True)

# LOGIN SSH
@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    
    async def login_ssh_(event):
        cmd = 'bot-cek-login-ssh'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
{z}
**shows logged in users SSH Ovpn**
**» 🤖@chapeey**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
    
    if a == "true":
        await login_ssh_(event)
    else:
        await event.answer("🛡 Unauthorized Access", alert=True)

# SSH MAIN MENU
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    
    async def ssh_(event):
        inline = [
            [Button.inline(" TRIAL SSH ", "trial-ssh"), Button.inline(" CREATE SSH ", "create-ssh")],
            [Button.inline(" DELETE SSH ", "delete-ssh"), Button.inline(" CHECK Login SSH ", "login-ssh")],
            [Button.inline(" SHOW All USER SSH ", "show-ssh"), Button.inline(" REGIS IP ", "regis")],
            [Button.inline("‹ Main Menu ›", "menu")]
        ]
        z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**⚡ SSH OVPN MANAGER ⚡**
━━━━━━━━━━━━━━━━━━━━━━━ 
✅ **» Service:** `SSH OVPN`
✅ **» Hostname/IP:** `{DOMAIN}`
✅ **» ISP:** `{z["isp"]}`
✅ **» Country:** `{z["country"]}`
🤖 **» @chapeey**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
        await event.edit(msg, buttons=inline)
    
    if a == "true":
        await ssh_(event)
    else:
        await event.answer("🛡 Unauthorized Access", alert=True)
