from kyt import *
import subprocess
import random
import time
import datetime as DT
import requests
from telethon import events, Button

# -------------------- Delete SSH Account --------------------
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
    async def delete_ssh_(event):
        async with bot.conversation(chat) as conv:
            await event.respond("**Username To Be Deleted:**")
            msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = msg.raw_text.strip()
            cmd = f'printf "%s\n" "{user}" | delssh'
        try:
            subprocess.check_output(cmd, shell=True)
        except Exception:
            await event.respond(f"**User** `{user}` **Not Found**")
        else:
            await event.respond(f"**Successfully Deleted** `{user}`")
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await delete_ssh_(event)
    else:
        await event.answer("🛡 Unauthorized Access", alert=True)

# -------------------- Create Premium SSH Account --------------------
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    async def create_ssh_(event):
        # Get username input
        async with bot.conversation(chat) as conv:
            await event.respond("**Username:**")
            msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = msg.raw_text.strip()
        # Get password input
        async with bot.conversation(chat) as conv:
            await event.respond("**Password:**")
            msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = msg.raw_text.strip()
        # Get expiry day selection
        async with bot.conversation(chat) as conv:
            await event.respond("**Choose Expiry Day**", buttons=[
                [Button.inline(" 3 Day ", b"3"),
                 Button.inline(" 7 Day ", b"7")],
                [Button.inline(" 30 Day ", b"30"),
                 Button.inline(" 60 Day ", b"60")]
            ])
            exp_msg = await conv.wait_event(events.CallbackQuery)
            exp = exp_msg.data.decode("ascii")
        await event.edit("Initializing account creation...")
        time.sleep(1)
        await event.edit("Validating user parameters...")
        time.sleep(1)
        await event.edit("Configuring system settings...")
        time.sleep(1)
        await event.edit("Finalizing account setup...")
        time.sleep(2)
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        try:
            subprocess.check_output(cmd, shell=True)
        except Exception:
            await event.respond("**User Already Exists or an Error Occurred**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            msg = f"""
**━━━━━━━━━━━━━━━━━**
**⚡ SSH OVPN ACCOUNT ⚡**
**━━━━━━━━━━━━━━━━━**
**» Username         :** `{user}`
**» Password         :** `{pw}`
**━━━━━━━━━━━━━━━━━**
**» Host             :** `{DOMAIN}`
**» Host Slowdns     :** `{HOST}`
**» Pub Key          :** `{PUB}`
**» Port OpenSSH     :** `443, 80, 22`
**» Port DNS         :** `443, 53, 22`
**» Port Dropbear    :** `443, 109`
**» Port Dropbear WS :** `443, 109`
**» Port SSH WS      :** `80, 8080, 8081-9999`
**» Port SSH SSL WS  :** `443`
**» Port SSL/TLS     :** `222-1000`
**» Port OVPN WS SSL :** `443`
**» Port OVPN SSL    :** `443`
**» Port OVPN TCP    :** `443, 1194`
**» Port OVPN UDP    :** `2200`
**» Proxy Squid      :** `3128`
**» BadVPN UDP       :** `7100, 7300, 7300`
**━━━━━━━━━━━━━━━━━**
**» Payload WSS      :** `GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━━**
**» OpenVPN WS SSL   :** `https://{DOMAIN}:81/ws-ssl.ovpn`
**» OpenVPN SSL      :** `https://{DOMAIN}:81/ssl.ovpn`
**» OpenVPN TCP      :** `https://{DOMAIN}:81/tcp.ovpn`
**» OpenVPN UDP      :** `https://{DOMAIN}:81/udp.ovpn`
**━━━━━━━━━━━━━━━━━**
**» Save Link Account:** `https://{DOMAIN}:81/ssh-{user}.txt`
**» Expired Until:** `{later}`
**» 🤖@chapeey**
"""
            await event.respond(msg)
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await create_ssh_(event)
    else:
        await event.answer("🛡 Unauthorized Access", alert=True)

# -------------------- Show All SSH Users --------------------
@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
    async def show_ssh_(event):
        cmd = 'bot-member-ssh'
        try:
            z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception:
            z = "Error retrieving SSH user list."
        await event.respond(f"""
        
 {z}
 
 **Show All SSH Users**
**» 🤖@chapeey**
""", buttons=[[Button.inline("‹ Main Menu ›", b"menu")]])
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await show_ssh_(event)
    else:
        await event.answer("🛡 Unauthorized Access", alert=True)

# -------------------- Create Trial SSH Account --------------------
@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    async def trial_ssh_(event):
        async with bot.conversation(chat) as conv:
            await event.respond("**Choose Expiry Minutes**", buttons=[
                [Button.inline("10 Minutes", b"10"),
                 Button.inline("15 Minutes", b"15")],
                [Button.inline("30 Minutes", b"30"),
                 Button.inline("60 Minutes", b"60")]
            ])
            exp_msg = await conv.wait_event(events.CallbackQuery)
            exp = int(exp_msg.data.decode("ascii"))

        user = "trialX" + str(random.randint(100, 1000))
        pw = "1"
        await event.edit("Initializing trial account creation...")
        time.sleep(1)
        await event.edit("Verifying trial parameters...")
        time.sleep(1)
        await event.edit("Allocating system resources...")
        time.sleep(1)
        await event.edit("Finalizing trial setup...")
        time.sleep(2)
        
        # Create the trial user without setting a system expiration date.
        cmd = f'useradd -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        try:
            subprocess.check_output(cmd, shell=True)
        except Exception:
            await event.respond("**User Already Exists or an Error Occurred**")
            return

        # Schedule deletion: first kill all user processes, then delete the user.
        delete_cmd = f'echo "pkill -KILL -u {user}; userdel -r {user}" | at now + {exp} minutes'
        # If needed, use absolute paths:
        # delete_cmd = f'echo "/usr/bin/pkill -KILL -u {user}; /usr/sbin/userdel -r {user}" | at now + {exp} minutes'
        try:
            subprocess.check_output(delete_cmd, shell=True)
        except Exception:
            await event.respond("**Failed to schedule deletion**")
            return

        msg = f"""
**━━━━━━━━━━━━━━━━━**
**⚡ SSH OVPN ACCOUNT ⚡**
**━━━━━━━━━━━━━━━━━**
**» Username         :** `{user}`
**» Password         :** `{pw}`
**━━━━━━━━━━━━━━━━━**
**» Expires In:** `{exp} Minutes`
**» 🤖@chapeey**
"""
        await event.respond(msg)
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await trial_ssh_(event)
    else:
        await event.answer("🛡 Unauthorized Access", alert=True)

# -------------------- Check Login SSH --------------------
@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
    async def login_ssh_(event):
        cmd = 'bot-cek-login-ssh'
        try:
            z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception:
            z = "Error checking logged-in SSH users."
        await event.respond(f"""
{z}

**Shows Logged-In SSH Ovpn Users**
**» 🤖@chapeey**
""", buttons=[[Button.inline("‹ Main Menu ›", b"menu")]])
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await login_ssh_(event)
    else:
        await event.answer("Access Denied", alert=True)

# -------------------- SSH Main Menu --------------------
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    async def ssh_(event):
        inline = [
            [Button.inline(" TRIAL SSH ", b"trial-ssh"),
             Button.inline(" CREATE SSH ", b"create-ssh")],
            [Button.inline(" DELETE SSH ", b"delete-ssh"),
             Button.inline(" CHECK Login SSH ", b"login-ssh")],
            [Button.inline(" SHOW All USER SSH ", b"show-ssh"),
             Button.inline(" REGIS IP ", b"regis")],
            [Button.inline("‹ Main Menu ›", b"menu")]
        ]
        try:
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        except Exception:
            z = {"isp": "N/A", "country": "N/A"}
        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**⚡ SSH OVPN MANAGER ⚡**
━━━━━━━━━━━━━━━━━━━━━━━
✅ **» Service:** `SSH OVPN`
✅ **» Hostname/IP:** `{DOMAIN}`
✅ **» ISP:** `{z.get("isp")}`
✅ **» Country:** `{z.get("country")}`
🤖 **» @chapeey**
━━━━━━━━━━━━━━━━━━━━━━━
"""
        await event.edit(msg, buttons=inline)
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await ssh_(event)
    else:
        await event.answer("🛡 Unauthorized Access", alert=True)